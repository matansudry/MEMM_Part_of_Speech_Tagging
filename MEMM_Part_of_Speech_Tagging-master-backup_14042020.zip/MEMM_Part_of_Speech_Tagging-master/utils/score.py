import numpy as np
import scipy
from scipy.optimize import fmin_l_bfgs_b


def accuracy(pred, true):
    return (np.array(pred) == np.array(true)).mean()


def top_k_erros():
    matan=1


def confusion_matrix():
        matan = 1
        # need to complete
